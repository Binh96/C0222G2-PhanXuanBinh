package com.phuong.exam;

public class MySearchException extends Exception{

    public MySearchException() {
    }

    public MySearchException(String message) {
        super(message);
    }
}
